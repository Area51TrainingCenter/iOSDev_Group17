//
//  PeliculaTableViewCell.swift
//  ProyectoPeliculas
//
//  Created by David Velarde on 5/19/17.
//  Copyright © 2017 David Velarde. All rights reserved.
//

import UIKit

class PeliculaTableViewCell: UITableViewCell {

    @IBOutlet weak var lblDescripcion: UILabel!
    @IBOutlet weak var imgPelicula: UIImageView!
    @IBOutlet weak var lblTitulo: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
